
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

public class MathUtiltest {

    @Test
    void mdcP1Pares() { //testando numeros pares
        final double a = 8, b = 2, esperado = b;
        final double obtido = MathUtil.mdc(a,b);
        assertEquals(esperado, obtido);
    }
    @Test
    void mdcP1NumerosIguais() { //testando numeros iguais
        final double a = 4, b = 4, esperado = b;
        final double obtido = MathUtil.mdc(a,b);
        assertEquals(esperado, obtido);
    }
    @Test
    void mdcP2(){
        final double a = 8, b = 4, divisor = 2;
        final double obtido = MathUtil.mdc(a,b);
        //assertEquals(0, obtido % divisor);
        assertTrue(obtido % divisor == 0); //quando se tem uma condição maior
        // |a| == valor positivo de a
    }
    @Test
    void mdcP3(){
        final double a = 5, esperado = a;
        final double obtido = MathUtil.mdc(a, 0);
        assertEquals(esperado, obtido);
    }

    @Test
    void mdcP3Positivo(){
        final double a = -5, esperado = a *-1;
        final double obtido = MathUtil.mdc(a,0);
        assertEquals(esperado, obtido);

    }

    @Test
    void mdcP3Negativo(){
        final double a = -5, esperado = a *-1;
        final double obtido = MathUtil.mdc(a,0);
        assertEquals(esperado, obtido);

    }

    @Test
    void mdcP4(){
        final double m = 5, a = 6, b = 3;
        final double esperado = MathUtil.mdc(m*a, m*b);
        final double obtido = m * MathUtil.mdc(a, b);
        assertEquals(esperado, obtido);

    }

    @Test
    void mdcP6(){
        final double a = 8, b = 4;
        final double esperado = MathUtil.mdc(a, b);
        final  double obtido = MathUtil.mdc (b, a);
        assertEquals(esperado, obtido);
    }

    @Test
    void mdcP7(){
        final double a = 12, b =3;
        final double esperado = MathUtil.mdc(-a, b);
        final double obtido = MathUtil.mdc(a, -b);
        assertEquals(esperado, obtido);
    }

    @Test
    void mdcP7Primos() {
        final double a = 7, b = 3;
        final double esperado = MathUtil.mdc(-a, b);
        final double obtido = MathUtil.mdc(a, -b);
        System.out.print("esperado: " + esperado + "obtido: " + obtido);
        assertEquals(esperado, obtido);
    }

    @Test
    void mdcP12(){
        final double p = 7;
        final double a = 2;

        final double obtido = MathUtil.mdc(p, a);
        assertEquals(1.0, obtido);

    }


    @Test
    void mdcP12UmNumeroPrimo(){
        final double p = 7;
        final double a = 7;

        final double obtido = MathUtil.mdc(p, a);
        assertEquals (p, obtido);

    }

    @Test
    void mdcP7PrimosIguais() {
        final double p = 7;
        final double a = p;
        final double obtido = MathUtil.mdc(p, a);
        System.out.print("esperado: " + p + "obtido: " + obtido);
        assertEquals(p, obtido);
    }
    @Test
    void mdcCasoGeralPares() { //testando numeros pares
        final double a = 12, b = 8, esperado = 4;
        final double obtido = MathUtil.mdc(a,b);
        assertEquals(esperado, obtido);
    }

}


