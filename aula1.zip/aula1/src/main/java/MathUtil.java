public class MathUtil {
    public static double mdc(double a, double b){


        //P7
        a = Math.abs(a);
        b = Math.abs(b);


        //P6

        final double min = Math.min(a, b);
        a = Math.max(a, b);
        b = min;

        if (a == b)
            return a;

        //P1 E P2
        if (b > 0 && a % b == 0)
            return b; //alt + enter para refatorar

        //P3
        if( b == 0)
            return Math.abs(a); //abs == valor absoluno
        //return a * -1;

        //throw new UnsupportedOperationException("Impossivel calcular com os valores informados");

        //P12

        return mdc(a-b, b);


    }
}

